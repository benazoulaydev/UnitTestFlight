﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlightSimulatorWebApi.Models
{
    public class Servers
    {
        public string ServerId { get; set; }

        public string ServerURL { get; set; }
    }
}
